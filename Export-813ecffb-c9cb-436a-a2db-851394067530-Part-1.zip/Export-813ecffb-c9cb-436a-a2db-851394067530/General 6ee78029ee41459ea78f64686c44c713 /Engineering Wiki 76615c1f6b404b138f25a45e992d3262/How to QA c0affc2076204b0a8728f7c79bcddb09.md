# How to QA

Owner: 2GI20CS184 
Tags: Guides and Processes, Testing
Last edited time: October 4, 2023 6:53 PM

<aside>
💡 This template explains our QA process for shipping bug-free software.

</aside>

# QA Philosophy

Write about your approach to QA and why it's critical to success. 

# Processes

### Making Code Changes

- Test PRs rigorously before requesting review.
- Include test cases you've checked for in your PR description.

### Reviewing Code

- If the change is substantial and user-facing, pull down the branch.
- Test for cases (particularly edge cases) that the PR author may have missed.

### QA

- Look at the list of items going out for release the next day.
- Go down the list one-by-one and thoroughly test changes.