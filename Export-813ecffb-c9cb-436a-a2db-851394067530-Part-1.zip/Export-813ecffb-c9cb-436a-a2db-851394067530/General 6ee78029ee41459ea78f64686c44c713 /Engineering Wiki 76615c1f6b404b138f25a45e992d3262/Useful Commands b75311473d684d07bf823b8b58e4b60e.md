# Useful Commands

Owner: 2GI20CS184 
Tags: Codebase, Guides and Processes
Last edited time: October 4, 2023 6:53 PM

<aside>
💡 Frequently used commands. This is a helpful page to [add to your Favorites](https://www.notion.so/7ef7287cee00464d9a813073b02ce24a?pvs=21).

</aside>

# 🚚 Run Locally

In the `acme` directory, run: 

```bash
acme run --local
```

For a full list of options, use:

```bash
acme --help
```

To run the typechecker on the entire codebase:

```bash
acme typecheck
```

# 🚢 Deployment

When you deploy to staging or production, run the following on the deployment server:

```bash
acme deploy --staging 
```

Replace `--staging` with `--prod` if deploying production.