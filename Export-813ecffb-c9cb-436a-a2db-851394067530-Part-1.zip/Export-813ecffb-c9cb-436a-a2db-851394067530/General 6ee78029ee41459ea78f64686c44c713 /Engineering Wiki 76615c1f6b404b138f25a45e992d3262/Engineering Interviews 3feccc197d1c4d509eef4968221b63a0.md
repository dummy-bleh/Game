# Engineering Interviews

Owner: 2GI20CS184 
Tags: Guides and Processes
Last edited time: October 4, 2023 6:53 PM

<aside>
💡 Use this template to document your approach to interviewing engineers!

</aside>

# Philosophy

Create a quote by typing `/quote` and pressing `enter`.

> Before you build a better mousetrap, it helps to know if there are any mice out there. —Yogi Berra
> 

# Interview Question Database

<aside>
💡 [Inline databases](https://www.notion.so/c523297c17634873a52317dd7a3e0b77?pvs=21) can be added to any page as tables, boards, calendars, lists or galleries. Just type `/database` to see your options.

</aside>

[Questions](Engineering%20Interviews%203feccc197d1c4d509eef4968221b63a0/Questions%20f2d9368753a74d23b796aaded3b01259.csv)

# Further Reading

For more on databases, check out this [Notion guide](https://www.notion.so/fd8cd2d212f74c50954c11086d85997e?pvs=21).