# Interview Question

# Description

Write a description for the interview question here.

# Sample Inputs

Give some valid inputs the candidate can expect to test their solution with.

- 

# Expected Outputs

For each sample input above, list the expected output. 

- 

# Solutions

Provide possible solutions in common languages to this problem.

### Javascript

```jsx
function solution() {
	
}
```

### Python

```python
def solution():
	pass
```