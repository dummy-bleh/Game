# FizzBuzz

Difficulty: Easy
Skills: Algorithms, Front end

<aside>
💡 Create a new question in this database and choose `Interview Question` from the list of templates to automatically generate the format below.

</aside>

# Description

Write a description for the interview question here.

# Sample Inputs

Give some valid inputs the candidate can expect to test their solution with.

- ...
- ...

# Expected Outputs

For each sample input above, list the expected output. 

- ...
- ...

# Solutions

Provide possible solutions in common languages to this problem.

### Javascript

```jsx
function solution() {
	
}
```

### Python

```python
def solution():
	pass
```