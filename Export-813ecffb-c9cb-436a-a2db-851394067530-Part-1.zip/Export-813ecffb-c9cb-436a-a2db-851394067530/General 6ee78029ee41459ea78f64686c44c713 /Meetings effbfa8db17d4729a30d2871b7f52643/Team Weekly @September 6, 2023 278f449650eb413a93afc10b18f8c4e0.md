# Team Weekly @September 6, 2023

Created by: Shradha Patil
Created time: September 7, 2023 7:46 PM
Event time: September 6, 2023 6:00 AM
Last edited by: Shradha Patil
Last edited time: September 7, 2023 7:46 PM
Type: Team weekly

## 📚 Pre-read

- Docs
    
    Add your docs here ...
    
- Team updates & gut checks
    
    Add your team members updates and gut checks here ...
    

## 📣 Agenda items

- 

## ☑️ Action items

- [ ]