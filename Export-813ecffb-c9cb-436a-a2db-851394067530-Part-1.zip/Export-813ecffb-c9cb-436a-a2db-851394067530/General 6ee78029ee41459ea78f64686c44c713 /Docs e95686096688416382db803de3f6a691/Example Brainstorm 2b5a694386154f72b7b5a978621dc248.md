# Example Brainstorm

Created by: Shradha Patil
Created time: September 7, 2023 7:46 PM
Last edited by: Shradha Patil
Last edited time: September 7, 2023 7:46 PM
Tags: Product

<aside>
💡 **Notion Tip:** Use this template to source ideas from your team even when you're not in the same room. Articulate a question you'd like to have answered. At the same time, people can add their bulleted ideas below that question and tag themselves. Click New topic to generate a new question to answer.

</aside>

# [Question to answer]

- First idea
- Second idea
- Third idea
- Fourth idea

# Whiteboard

<aside>
💡 **Notion Tip:** Notion makes it easy to pull in brainstorming resources from other apps so you all stay focused on the same doc. For instance, you can embed mind-mapping boards from Miro and files from Figma that will update in real time.

</aside>

↓ Embed examples below

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)