# Literature Survey

Assignee: Shradha Patil, Vinit gunaki, NIDHI PATIL, Srushti Mudennavar, 2GI20CS184 
Status: Done
Summary: Research about how self-paced learning is more effective than a traditional classroom based environment.
Gamifying education
Due: September 22, 2023 → September 22, 2023
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Priority: High
Dates: August 20, 2023 → August 22, 2023

# Proof of work

Please maintain your research organized you need to put forth your ideas.

[https://consensus.app/details/furthermore-group-self-instruction-classroom-mitra/71097ca8c5305e3fb0cb3addd0648a1d/](https://consensus.app/details/furthermore-group-self-instruction-classroom-mitra/71097ca8c5305e3fb0cb3addd0648a1d/)

Research by the National Training Laboratories suggests that learners retain approximately 5% of what they learn from lectures, compared to 90% when they teach others. Self-learners have more control over their teaching and learning methods, which can enhance retention.

A study published in the International Journal of E-Learning & Distance Education found that online learners who have control over their learning schedules tend to perform better and have higher satisfaction levels.

A meta-analysis published in the Review of Educational Research found that problem-based learning, a form of self-directed learning, was associated with better problem-solving skills and knowledge transfer to real-world scenarios.