# Web Development Track

Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: Learning (Learning%20eb405f9079c74e858153e15a5a67e28e.md)

## Resources

1. Create a github [student developer pack](https://education.github.com/pack) account
    - Stuff worth checking out using GitHub student developers click [here](https://education.github.com/pack#offers)
        - Github
        - VS code
        - Namecheap
        - Frontend master
        - Git lens
2. Enroll to [Frontendmasters](https://frontendmasters.com/welcome/github-student-developers/) program and get started with web dev 
3. Learn Git and GitHub from [Dan Gitschooldude](https://www.youtube.com/watch?v=OZEGnam2M9s&list=PLu-nSsOS6FRIg52MWrd7C_qSnQp3ZoHwW&index=3) on linux.

## Description

-