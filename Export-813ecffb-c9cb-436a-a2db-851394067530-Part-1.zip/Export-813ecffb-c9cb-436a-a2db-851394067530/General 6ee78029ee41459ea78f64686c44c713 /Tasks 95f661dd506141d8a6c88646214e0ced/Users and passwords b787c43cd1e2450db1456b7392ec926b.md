# Users and passwords

Status: Done
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: Setup the environment (Setup%20the%20environment%2081a533ff93094ce59383a4cb6934b24d.md)

## Description

> level | pass |
> 

> :—- | :—- |
> 

level00

pass:level00

level01

pass:Eengoh8f

level02

pass : yeez5Ohd

level03

pass:bLeh!WHat?

level04

pass: level04