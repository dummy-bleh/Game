# Implement Hardware challenges

Assignee: 2GI20CS184 , NIDHI PATIL, Srushti Mudennavar, Shradha Patil, Vinit gunaki, Declan Rodrigues
Status: In progress
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Sub-tasks: Level00 (Level00%204abccb0fa8a8439c992dce50ee6c9033.md), Level01 (Level01%206386c14644fb4610b227b65ca4f3ef1b.md), Level02 (Level02%207debdeef6a744714a5f40bd356465f4f.md)

## About this project

- 

## Project tasks

[Tasks](Implement%20Hardware%20challenges%206fd5d037923d41738f198da034343cba/Tasks%20ce472adada7e49818dca83a0af0c857c.csv)