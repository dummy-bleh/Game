# Setup the environment

Assignee: 2GI20CS184 , NIDHI PATIL, Srushti Mudennavar, Vinit gunaki, Shradha Patil, Declan Rodrigues
Status: Done
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Sub-tasks: Installing the operating system (Installing%20the%20operating%20system%20fd4e7214eccf4f53b69cef5d9fa6df9b.md), SSH (SSH%20e7bce3a2c71048408af53c5e1d56a9fe.md), Install Apache server daemon (Install%20Apache%20server%20daemon%20cbf45239266a468786f85fe59762f90c.md), figlet config & Banner (figlet%20config%20&%20Banner%20624c36637b16475b983ea199230ab115.md), Creating Users (Creating%20Users%20f32c431c3b3f446b8586265f7c2bfb16.md), Users and passwords (Users%20and%20passwords%20b787c43cd1e2450db1456b7392ec926b.md), password generation (password%20generation%205a0ed666e5db40a2b76b6352f7f87fa1.md), Changing Passwords (Changing%20Passwords%20359d713f03eb4ba3801e83e204f373b1.md), Setting up web server (Setting%20up%20web%20server%20cf5df20caa2d471a9b63e41b160c2edb.md)

## Description

-