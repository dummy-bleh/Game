# Users and groups

Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: Create the game structure (Create%20the%20game%20structure%20938d0296baf44351a3da0561dd7db552.md)

## Users and groups

`ls -l /home` Check for users on the operating system

`cat etc/passwd` Shows all the users on the operating system. Pipe thorough `wc -l` to get a number of total users on the operating system.

## Add and remove user with home directory

`sudo useradd <username>` Add a new user without the home directory

`sudo useradd -m <username>` Add a new user with the home directory

`sudo userdel <username>` Remove the user without the home directory

`sudo userdel -r <username>` Remove the user and associated home directory

## Add password

`sudo passwd <new password>`