# Level00

Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: Implement Hardware challenges (Implement%20Hardware%20challenges%206fd5d037923d41738f198da034343cba.md)

## Description

-