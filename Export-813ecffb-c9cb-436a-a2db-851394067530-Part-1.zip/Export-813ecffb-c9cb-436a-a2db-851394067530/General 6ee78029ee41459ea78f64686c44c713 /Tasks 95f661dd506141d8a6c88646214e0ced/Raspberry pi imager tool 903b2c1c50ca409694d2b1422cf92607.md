# Raspberry pi imager tool

Status: Done
Parent-task: Installing the operating system (Installing%20the%20operating%20system%20fd4e7214eccf4f53b69cef5d9fa6df9b.md)

## Description

- Download the raspberry pi imager from

[Raspberry Pi OS – Raspberry Pi](https://www.raspberrypi.com/software/)

- Use a SD no less than 4 GB, let’s then that will have performance issues
- Choose the operating system accordingly if your pi is raspberry model B then go ahead with 64 but operating system
- If you are a beginner the. I recommend ****Raspberry Pi OS with desktop**** and more experienced users can use the headless version which is purely cli, ****raspberry pi os lite 64 bit without desktop environment****
- Finally write it to the SD card.