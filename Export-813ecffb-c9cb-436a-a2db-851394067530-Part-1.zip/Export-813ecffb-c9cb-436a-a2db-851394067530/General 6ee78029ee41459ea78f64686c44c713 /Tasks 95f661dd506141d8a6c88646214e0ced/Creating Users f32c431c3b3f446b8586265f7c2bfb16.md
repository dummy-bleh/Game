# Creating Users

Status: Done
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Sub-tasks: adduser (adduser%2098b2e23950ea4b998a2a13f199aaf8c0.md), useradd (useradd%20f87313b4faef47008700bc13d2f093b3.md)
Parent-task: Setup the environment (Setup%20the%20environment%2081a533ff93094ce59383a4cb6934b24d.md)

## Creating user

To create user accounts on a Linux system, you can use either of the commands

1. `adduser` (Beginner friendly)
2. `useradd` (requires complete knowledge of system and user files)