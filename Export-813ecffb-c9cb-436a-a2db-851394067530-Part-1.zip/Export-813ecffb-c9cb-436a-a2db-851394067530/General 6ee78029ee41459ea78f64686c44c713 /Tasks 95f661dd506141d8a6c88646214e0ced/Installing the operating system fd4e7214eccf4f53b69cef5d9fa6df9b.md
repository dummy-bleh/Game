# Installing the operating system

Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Sub-tasks: Raspberry pi imager tool (Raspberry%20pi%20imager%20tool%20903b2c1c50ca409694d2b1422cf92607.md)
Parent-task: Setup the environment (Setup%20the%20environment%2081a533ff93094ce59383a4cb6934b24d.md)

-