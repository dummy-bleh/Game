# password generation

Status: Done
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: Setup the environment (Setup%20the%20environment%2081a533ff93094ce59383a4cb6934b24d.md)

## Description

- apt is a commandline package manager and provides commands for
searching and managing as well as querying information about packages.
It provides the same functionality as the specialized APT tools

`sudo apt search pwgen`