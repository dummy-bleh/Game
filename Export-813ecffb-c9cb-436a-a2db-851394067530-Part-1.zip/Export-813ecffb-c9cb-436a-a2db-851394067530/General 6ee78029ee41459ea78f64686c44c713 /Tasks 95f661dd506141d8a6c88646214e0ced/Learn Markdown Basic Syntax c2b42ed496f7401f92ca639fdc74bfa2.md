# Learn Markdown Basic Syntax

Assignee: Shradha Patil, Srushti Mudennavar, 2GI20CS184 , Vinit gunaki, NIDHI PATIL
Status: In progress
Summary: Markdown is essential in learning how to document things on GitHub and also notion, the shortcuts on notion are actually markdown syntax, so please do learn at least the basic syntax for starters. You will know how powerful this skill actually is when you start using it to document things.
Due: September 22, 2023
Priority: Low
Parent-task: Documentation and help (Documentation%20and%20help%20ca92cef4ddbd47628b78862c71d34f03.md)

# Learn Markdown Basic Syntax

- Create a GitHub repository named **Markdown basics**. In the `[README.md](http://readme.md/)` file, recreate the Basic syntax table from your file.
- [**Link**](https://github.com/1337encrypted/zet#headings)