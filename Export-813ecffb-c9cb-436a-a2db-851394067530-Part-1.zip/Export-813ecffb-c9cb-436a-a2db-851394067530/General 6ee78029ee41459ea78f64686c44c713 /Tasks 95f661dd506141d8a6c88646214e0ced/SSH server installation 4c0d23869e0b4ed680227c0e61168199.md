# SSH server installation

Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Parent-task: SSH (SSH%20e7bce3a2c71048408af53c5e1d56a9fe.md)

## Installation

- Ssh has server software and client software, both are independent of each other

`sudo apt install openssh-server`