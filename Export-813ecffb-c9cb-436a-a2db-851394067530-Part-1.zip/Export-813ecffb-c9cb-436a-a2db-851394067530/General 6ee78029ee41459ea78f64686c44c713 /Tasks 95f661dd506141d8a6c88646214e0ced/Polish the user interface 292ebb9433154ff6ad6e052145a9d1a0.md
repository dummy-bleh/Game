# Polish the user interface

Assignee: 2GI20CS184 , NIDHI PATIL, Srushti Mudennavar, Shradha Patil, Vinit gunaki, Declan Rodrigues
Status: Not started
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)

## Description

-