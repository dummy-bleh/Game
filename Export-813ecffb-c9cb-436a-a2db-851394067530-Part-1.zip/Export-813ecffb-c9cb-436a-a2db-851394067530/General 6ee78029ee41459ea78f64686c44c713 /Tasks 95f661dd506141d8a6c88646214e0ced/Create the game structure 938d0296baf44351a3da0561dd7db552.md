# Create the game structure

Assignee: 2GI20CS184 , NIDHI PATIL, Srushti Mudennavar, Shradha Patil, Vinit gunaki, Declan Rodrigues
Status: In progress
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Sub-tasks: Users and groups (Users%20and%20groups%2015e2b21409f34123988eda58f4fa325a.md)

## About this project

- 

## Project tasks

[Tasks](Create%20the%20game%20structure%20938d0296baf44351a3da0561dd7db552/Tasks%20c0fabab340cc4ee5a9e24ff2042b9cb2.csv)