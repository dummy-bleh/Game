# Design the game

Assignee: 2GI20CS184 , NIDHI PATIL, Srushti Mudennavar, Shradha Patil, Vinit gunaki, Declan Rodrigues
Status: In progress
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)

## About this project

- 

## Project tasks

[Tasks](Design%20the%20game%20213633a0732b4e18b839b7a0bd69cd67/Tasks%20009e61c80e8e4a0b9f9c2491dec3e6f7.csv)

[Creating users](Design%20the%20game%20213633a0732b4e18b839b7a0bd69cd67/Creating%20users%20477d6d3d940a425b9903f72bf461f7ee.md)