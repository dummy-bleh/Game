# Connect via SSH

Status: Not started
Parent-task: SSH (SSH%20e7bce3a2c71048408af53c5e1d56a9fe.md)

usage, for more command flags use the man pages or type `ssh —help`

### Syntax

```bash
ssh <username>@<ipaddres>
```

If you are connecting for the first time then type yes before it prompts you for the password.

### Different port

```bash
ssh username@ipaddress -p port
```