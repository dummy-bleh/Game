# Documentation and help

Assignee: 2GI20CS184 , Shradha Patil, Srushti Mudennavar, Declan Rodrigues, Vinit gunaki, NIDHI PATIL
Status: In progress
Project: Hardware CTF (../Projects%20830fc3382fb34285a2a17fc2afb323f7/Hardware%20CTF%208c3da23affc748f994cf065bdc2db69b.md)
Priority: Low
Dates: September 20, 2023
Sub-tasks: Learn Markdown Basic Syntax (Learn%20Markdown%20Basic%20Syntax%20c2b42ed496f7401f92ca639fdc74bfa2.md)